# ⚡ QuantBot — Crypto Futures Signal Engine

Bot de análisis técnico para futuros de criptomonedas. Desplegable en Netlify en menos de 5 minutos.

---

## 🚀 Deploy en Netlify (3 pasos)

### Opción A — GitHub + Netlify (recomendado)

1. Sube esta carpeta a un repositorio de GitHub
2. En [netlify.com](https://netlify.com) → "Add new site" → "Import from Git"
3. Configura:
   - **Publish directory:** `public`
   - **Functions directory:** `netlify/functions`
4. Click "Deploy site" ✅

### Opción B — Netlify CLI

```bash
npm install -g netlify-cli
cd crypto-bot
netlify deploy --prod
```

### Desarrollo local

```bash
npm install
netlify dev
# Abre http://localhost:8888
```

---

## 🧠 Lógica de Análisis (Backend Serverless)

### Filtrado inicial
- Solo pares USDT en Binance Futures Perpetuos
- Cambio 24h: +3% a +50% (evita pump & dump)
- Volumen 24h mínimo: $5,000,000
- Top 20 ganadores del momento

### Sistema de puntuación (0–100 pts)

| Criterio | Puntos |
|---|---|
| EMAs alcistas alineadas (15m + 1h) | +25 |
| RSI 15m zona ideal 50–70 | +15 |
| RSI 1h zona ideal 50–70 | +10 |
| Volumen 1.5x+ sobre la media | +15 |
| Volumen 1.0–1.5x sobre la media | +8 |
| Tendencia de volumen alcista | +10 |
| Patrón de vela alcista 15m | +10 |
| Vela alcista 1h | +5 |
| Precio cerca de soporte | +10 |
| Pendiente EMA20 positiva | +5 |

### Clasificación de señales

- **ENTRAR** (verde): Score ≥ 65 + patrón alcista + volumen ≥ 1x + R:R ≥ 1.5
- **ESPERAR** (amarillo): Score 45–64 o RSI sobrecomprado (>80) o volumen débil
- **DESCARTAR** (gris): No cumple criterios mínimos

### Gestión de riesgo
- **Entrada:** Precio actual
- **Stop Loss:** Por debajo del soporte dinámico (max de EMA50_15m y soporte histórico)
- **TP1:** Entrada + 1.5× riesgo (conservador)
- **TP2:** Extensión Fibonacci 1.618 sobre el rango S/R
- **R:R mínimo:** 1:1.5

---

## 📁 Estructura del proyecto

```
crypto-bot/
├── public/
│   └── index.html          # Dashboard frontend
├── netlify/
│   └── functions/
│       ├── scan-market.js  # Motor de análisis técnico
│       └── get-price.js    # Precio en tiempo real
├── netlify.toml            # Configuración Netlify
├── package.json
└── README.md
```

---

## ⚠️ Aviso de riesgo

Este bot es una herramienta educativa y de análisis técnico. **No constituye asesoramiento financiero.** El trading de futuros de criptomonedas implica riesgo de pérdida total del capital. Usa siempre stop loss y gestiona tu riesgo de forma responsable.
